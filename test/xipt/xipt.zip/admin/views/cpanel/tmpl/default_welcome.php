<?php
/**
* @Copyright Ready Bytes Software Labs Pvt. Ltd. (C) 2010- author-Team Joomlaxi
* @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
**/
// Disallow direct access to this file
if(!defined('_JEXEC')) die('Restricted access');
?>
<table class="adminlist">
		<tr>
			<td>
				<div style="font-weight:700;">
				<p>
					JoomlaXi is a team of professional web developers dedicated to deliver high-quality extensions, unique solutions and advanced services for Joomla!, the most popular open source Content Management System (CMS) worldwide.<br /><br />Our Other Products<br /><br />1. <a href= "http://www.joomlaxi.com/products/paid-products/joomlaxi-user-search-xius.html">JoomlaXi User Search: </a>An advanced User Search Engine
developed to improve JomSocial search.<br />2. <a href= "http://www.joomlaxi.com/products/paid-products/jomsocial-profile-completeness.html">JomSocial Profile Completeness: </a> A unique Component to show user's Profile Completeness on their profile page
				</p>
				</div>
			</td>
		</tr>
	</table>
<?php 

