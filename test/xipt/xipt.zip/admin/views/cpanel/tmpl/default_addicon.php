<?php
/**
* @Copyright Ready Bytes Software Labs Pvt. Ltd. (C) 2010- author-Team Joomlaxi
* @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
**/
// Disallow direct access to this file
if(!defined('_JEXEC')) die('Restricted access');
?>
<div style="float:left;">
	<div class="icon">
		<a	href="<?php echo $this->url; ?>" <?php echo $this->newWindow; ?> >
			<img alt="<?php echo $this->text; ?>" src="../components/com_xipt/assets/images/<?php echo $this->image; ?>">
			<span><?php echo $this->text; ?></span>
		</a>		
	</div>
</div>
<?php 
