<?php
/**
* @Copyright Ready Bytes Software Labs Pvt. Ltd. (C) 2010- author-Team Joomlaxi
* @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
**/
// Disallow direct access to this file
if(!defined('_JEXEC')) die('Restricted access');
?>
<div style="text-align:center; width:100%; border-top: solid #DDDDDD 1px; margin-top:20px; padding-top: 5px;">
	<div>
		<a href='http://www.joomlaxi.com/downloads/jomsocial-multi-profile-types.html' target="_blank"><?php echo XiptText::_('DOWNLOAD');?></a>
		| <a href='http://www.joomlaxi.com/support/forum/45-jspt-30.html' target="_blank"><?php echo XiptText::_('SUPPORT');?></a>
		| <a href='http://www.gnu.org/licenses/old-licenses/gpl-2.0.html' target="_blank"><?php echo XiptText::_('LICENSE');?></a>
		| <a href='http://twitter.com/joomlaXi' target="_blank"><?php echo XiptText::_('FOLLOW_TWITTER');?></a>
		| <a href='http://extensions.joomla.org/extensions/extension-specific/jomsocial-extensions/8230' target="_blank"><?php echo XiptText::_('REVIEW_JED');?></a>
	</div>
	<div class="clr"></div>
	<div>
		<span style="color: #555555;">
			<?php echo XiptText::_('CURRENT_VERSION').' '.XIPT_VERSION;?>
		</span>
	</div>
</div>
<?php 