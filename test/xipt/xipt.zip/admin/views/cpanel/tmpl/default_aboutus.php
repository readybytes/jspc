<?php
/**
* @Copyright Ready Bytes Software Labs Pvt. Ltd. (C) 2010- author-Team Joomlaxi
* @license GNU/GPL http://www.gnu.org/copyleft/gpl.html
**/
// Disallow direct access to this file
if(!defined('_JEXEC')) die('Restricted access');
?>
<table class="adminlist">
		<tr>
			<td>
				<div style="font-weight:700;">
					JoomlaXi is a team of professional web developers dedicated to deliver high-quality extensions, unique solutions and advanced services for Joomla!, the most popular open source Content Management System (CMS) worldwide.				 
				</div>
				<p>
					Support : <a href="http://www.joomlaxi.com/support/forum.html" target="_blank">
					http://www.joomlaxi.com/support/forum.html
					</a>
				</p>
				<p>
					Through JSPT it is possible to create unlimited number of ProfileTypes.Every field of Profile can be assigned to any number of profiles-type or to ALL. Moreover, Well Organized user management is achieved.
				</p>
			</td>
		</tr>
	</table>
<?php 
