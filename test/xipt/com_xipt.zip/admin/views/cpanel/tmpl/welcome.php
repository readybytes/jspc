<?php
	echo $this->pane->startPanel( JText::_('WELCOME TO XIPT') , 'welcome' );
	?>
	<table class="adminlist">
		<tr>
			<td>
				<div style="font-weight:700;">
					<?php echo JText::_('ANOTHER GREAT COMPONENT BROUGHT TO YOU BY JOOMLAXI.COM');?>
				</div>
				<p>
					Support : <a href="http://www.joomlaxi.com/support/forum.html" target="_blank">
					http://www.joomlaxi.com/support/forum.html
					</a>
				</p>
			</td>
		</tr>
	</table>
<?php
	echo $this->pane->endPanel();