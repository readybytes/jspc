<?php
// no direct access
defined('_JEXEC') or die('Restricted access');
 
class XiPTControllerCPanel extends JController 
{
  
	function __construct($config = array())
	{
		parent::__construct($config);
	}
	
    function display() 
	{
		parent::display();
    }
	
}